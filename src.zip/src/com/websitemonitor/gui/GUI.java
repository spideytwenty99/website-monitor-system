package com.websitemonitor.gui;

// Represents the graphical user interface.
public class GUI {
    public void displayInterface(){
        System.out.println("******Displaying Website Monitor GUI******\n");
    }
}
