package com.websitemonitor.ObserverPattern;

public interface Subject {
    void attachObserver(Observer o);
    void detachObserver(Observer o);
    void notifyObserver(String websiteUrl);
}
