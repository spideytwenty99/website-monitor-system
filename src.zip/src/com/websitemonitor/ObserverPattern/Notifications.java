package com.websitemonitor.ObserverPattern;

import com.websitemonitor.communication.CommunicationChannel;
import com.websitemonitor.model.User;

public class Notifications implements Observer{

    private User u;
    public Notifications(User u){
        this.u=u;

    }

    @Override
    public void update(String websiteUrl) {
        String msg ="Update detected on: " + websiteUrl;
        sendNotification(msg);

    }
    public void sendNotification(String message){
        for (CommunicationChannel channel: u.getChannels()){
            channel.deliverMessage(message);
        }
    }

}
