package com.websitemonitor.ObserverPattern;

import com.websitemonitor.communication.Gmail;
import com.websitemonitor.communication.Sms;
import com.websitemonitor.gui.GUI;
import com.websitemonitor.model.Registration;
import com.websitemonitor.model.Subscription;
import com.websitemonitor.model.User;
import com.websitemonitor.model.Website;


public class Main {

    public static void main(String[] args) {

        GUI g=new GUI();
        g.displayInterface();

        SoftwareController controller=new SoftwareController();

        User u1=new User("saruabh10",10,"saruabh@gmail.com","theGoatMessi");
        u1.addChannel(new Gmail("saurabh@gmail.com"));
        u1.addChannel(new Sms("015754984846"));

        User u2 = new User("Thomas", 11, "thomas@gmail.com", "thomas123");
        u2.addChannel(new Gmail("thomas@gmail.com"));

        Registration r = new Registration(100);
        controller.handleUserRegistration(r, u1);
        controller.handleUserRegistration(r, u2);

        Website w = new Website("https://java&uml.com");
        Subscription s1 = new Subscription(1042, w);
        Subscription s2 = new Subscription(1043, w);

        System.out.println();
        controller.handleSubscriptionActivation(s1);
        controller.handleSubscriptionActivation(s2);
        System.out.println();


        updateChecker c = new updateChecker(10);


        Notifications n1 = new Notifications(u1);
        Notifications n2 = new Notifications(u2);
        controller.handleRegisterObserver(c,n1);
        controller.handleRegisterObserver(c,n2);


        controller.handleUpdateRequest(c, w);

        System.out.println("\n--- u1 unsubscribes ---");
        c.detachObserver(n1);

        System.out.println("\n--- Now only u2 gets notified ---");
        c.checkForUpdates(w);


    }

}
