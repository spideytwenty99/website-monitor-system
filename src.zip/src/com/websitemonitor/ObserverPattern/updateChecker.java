package com.websitemonitor.ObserverPattern;

import com.websitemonitor.model.Website;

import java.util.ArrayList;

public class updateChecker implements Subject {

    private int checkInterval;

    private ArrayList<Observer>observers=new ArrayList<>();


    public updateChecker(int interval){
        this.checkInterval=interval;

    }


    @Override
    public void attachObserver(Observer o) {
        observers.add(o);
        System.out.println("Observer attached successfully");
    }

    @Override
    public void detachObserver(Observer o) {
        observers.remove(o);
        System.out.println("Observer removed successfully");
    }

    @Override
    public void notifyObserver(String websiteUrl) {
        System.out.println("Notifying observers of change on: "+websiteUrl);
        for (Observer o: observers){
            o.update(websiteUrl);
        }
    }

    public void monitor(Website w){
        System.out.println("\nMonitoring: "+w.getUrl());
    }

    public  boolean detectUpdate(){
        return true;
    }

    public void checkForUpdates(Website w){
        monitor(w);
        if (detectUpdate()){
            notifyObserver(w.getUrl());
        }
    }
}

