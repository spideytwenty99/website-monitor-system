package com.websitemonitor.ObserverPattern;

public interface Observer {
    void update(String websiteUrl);
}
